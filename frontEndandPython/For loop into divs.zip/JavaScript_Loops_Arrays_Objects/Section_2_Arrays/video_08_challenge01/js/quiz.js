
function print(message) {
  document.write(message);
}
